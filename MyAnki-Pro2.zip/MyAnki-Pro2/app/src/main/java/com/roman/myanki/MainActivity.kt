package com.roman.myanki

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private data class Card(
    val id: String,
    val front: String,
    val reading: String,
    val meaning: String,
    val deck: String,
    var interval: Int = 0,
    var repetitions: Int = 0,
    var lapses: Int = 0,
    var dueDay: Long = 0L
)

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var tts: TextToSpeech
    private var speechReady = false
    private var speechRate = 0.82f
    private var currentDeck = "GENKI 1 • Основи"
    private var reviewIndex = 0
    private var revealed = false

    private val cards = mutableListOf(
        Card("nihon", "日本", "にほん", "Японія", "GENKI 1 • Основи"),
        Card("gakusei", "学生", "がくせい", "Студент", "GENKI 1 • Основи"),
        Card("sensei", "先生", "せんせい", "Учитель / викладач", "GENKI 1 • Основи"),
        Card("kaishain", "会社員", "かいしゃいん", "Працівник компанії", "GENKI 1 • Основи"),
        Card("kazoku", "家族", "かぞく", "Сім'я", "Сім'я"),
        Card("ani", "兄", "あに", "Старший брат", "Сім'я"),
        Card("ane", "姉", "あね", "Старша сестра", "Сім'я"),
        Card("otouto", "弟", "おとうと", "Молодший брат", "Сім'я"),
        Card("imouto", "妹", "いもうと", "Молодша сестра", "Сім'я"),
        Card("ikura", "いくら", "いくら", "Скільки коштує?", "Магазин"),
        Card("takai", "たかいですね", "たかいですね", "Дорого, правда?", "Магазин"),
        Card("jaa", "じゃあ", "じゃあ", "Тоді / ну тоді", "Магазин"),
        Card("kudasai", "ください", "ください", "Дайте, будь ласка", "Магазин"),
        Card("desu", "です", "です", "Ствердження", "Граматика"),
        Card("desuka", "ですか", "ですか", "Питання", "Граматика"),
        Card("jaarimasen", "じゃありません", "じゃありません", "Заперечення", "Граматика")
    )

    private fun nowDay(): Long = System.currentTimeMillis() / 86_400_000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("myanki", Context.MODE_PRIVATE)
        speechRate = prefs.getFloat("speech_rate", 0.82f)
        loadProgress()
        tts = TextToSpeech(this, this)
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(16), dp(20), dp(16))
        setBackgroundColor(0xFFF7F8FC.toInt())
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 28f
        setTypeface(null, Typeface.BOLD)
        setTextColor(0xFF171A21.toInt())
        setPadding(0, 0, 0, dp(12))
    }

    private fun button(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 16f
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) }
    }

    private fun info(text: String, size: Float = 16f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFF4B5563.toInt())
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun setScreen(content: View) {
        setContentView(ScrollView(this).apply { addView(content) })
    }

    private fun bottomNav(onHome: () -> Unit, onDecks: () -> Unit, onStats: () -> Unit, onSettings: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
            addView(navButton("Головна", onHome))
            addView(navButton("Колоди", onDecks))
            addView(navButton("Статистика", onStats))
            addView(navButton("Налаштування", onSettings))
        }
    }

    private fun navButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 12f
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(2); marginEnd = dp(2) }
    }

    private fun showHome() {
        val r = root()
        r.addView(title("MyAnki"))
        r.addView(info("Твій особистий тренажер японської", 18f))

        val due = cards.count { it.dueDay <= nowDay() }
        val totalReviews = prefs.getInt("total_reviews", 0)
        r.addView(info("Сьогодні готові до повторення: $due", 17f))
        r.addView(info("Усього повторень: $totalReviews"))
        r.addView(info("Поточна колода: $currentDeck"))

        r.addView(button("▶ Почати повторення") { startReview(currentDeck) })
        r.addView(button("📚 Вибрати колоду") { showDecks() })
        r.addView(button("📊 Відкрити статистику") { showStats() })
        r.addView(info("Мета на день", 18f))
        val goal = prefs.getInt("daily_goal", 10)
        val today = prefs.getInt("today_reviews", 0)
        r.addView(info("$today / $goal повторень"))
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = goal
            progress = minOf(today, goal)
            layoutParams = LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(4); bottomMargin = dp(10) }
        }
        r.addView(progress)
        r.addView(bottomNav(::showHome, ::showDecks, ::showStats, ::showSettings))
        setScreen(r)
    }

    private fun showDecks() {
        val r = root()
        r.addView(title("Колоди"))
        listOf("GENKI 1 • Основи", "Сім'я", "Магазин", "Граматика").forEach { deck ->
            val count = cards.count { it.deck == deck }
            val due = cards.count { it.deck == deck && it.dueDay <= nowDay() }
            r.addView(button("$deck\n$count карток • $due готові") {
                currentDeck = deck
                startReview(deck)
            })
        }
        r.addView(bottomNav(::showHome, ::showDecks, ::showStats, ::showSettings))
        setScreen(r)
    }

    private fun startReview(deck: String) {
        currentDeck = deck
        val deckCards = cards.filter { it.deck == deck }
        if (deckCards.isEmpty()) return
        reviewIndex = deckCards.indexOfFirst { it.dueDay <= nowDay() }.let { if (it < 0) 0 else it }
        revealed = false
        showReview(deckCards)
    }

    private fun showReview(deckCards: List<Card>) {
        if (deckCards.isEmpty()) {
            showDecks()
            return
        }
        val card = deckCards[reviewIndex % deckCards.size]
        val r = root()
        r.addView(title("Повторення"))
        r.addView(info(currentDeck, 15f))

        val counter = info("Картка ${reviewIndex + 1} з ${deckCards.size}", 15f)
        r.addView(counter)

        val cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(26), dp(16), dp(26))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val front = TextView(this).apply {
            text = card.front
            textSize = 48f
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF111827.toInt())
        }
        cardBox.addView(front)
        val back = TextView(this).apply {
            text = "${card.reading}\n\n${card.meaning}"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(0xFF374151.toInt())
            visibility = if (revealed) View.VISIBLE else View.GONE
            setPadding(0, dp(18), 0, 0)
        }
        cardBox.addView(back)
        r.addView(cardBox)

        r.addView(button(if (revealed) "🔊 Повторити озвучення" else "👁 Показати відповідь") {
            if (!revealed) {
                revealed = true
                back.visibility = View.VISIBLE
                speak(card.front)
                showReview(deckCards)
            } else speak(card.front)
        })

        if (revealed) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(ratingButton("Важко", 1), LinearLayout.LayoutParams(0, dp(58), 1f))
            row.addView(ratingButton("Добре", 2), LinearLayout.LayoutParams(0, dp(58), 1f))
            row.addView(ratingButton("Легко", 3), LinearLayout.LayoutParams(0, dp(58), 1f))
            r.addView(row)
        }

        r.addView(button("← На головну") { showHome() })
        setScreen(r)
    }

    private fun ratingButton(label: String, level: Int): Button = Button(this).apply {
        text = label
        textSize = 14f
        setOnClickListener {
            val deckCards = cards.filter { it.deck == currentDeck }
            val card = deckCards[reviewIndex % deckCards.size]
            rate(card, level)
            revealed = false
            reviewIndex = (reviewIndex + 1) % deckCards.size
            showReview(deckCards)
        }
    }

    private fun rate(card: Card, level: Int) {
        val oldInterval = card.interval
        card.repetitions++
        if (level == 1) {
            card.lapses++
            card.interval = max(1, oldInterval / 2)
        } else if (level == 2) {
            card.interval = if (oldInterval == 0) 1 else max(1, oldInterval * 2)
        } else {
            card.interval = if (oldInterval == 0) 4 else max(2, oldInterval * 4)
        }
        card.dueDay = nowDay() + card.interval

        val total = prefs.getInt("total_reviews", 0) + 1
        val today = if (prefs.getLong("last_review_day", -1) == nowDay()) prefs.getInt("today_reviews", 0) + 1 else 1
        prefs.edit()
            .putInt("total_reviews", total)
            .putInt("today_reviews", today)
            .putLong("last_review_day", nowDay())
            .apply()
        saveCard(card)
    }

    private fun showStats() {
        val r = root()
        r.addView(title("Статистика"))
        val total = prefs.getInt("total_reviews", 0)
        val today = prefs.getInt("today_reviews", 0)
        val mastered = cards.count { it.interval >= 7 }
        val learning = cards.count { it.repetitions > 0 && it.interval < 7 }
        val due = cards.count { it.dueDay <= nowDay() }
        r.addView(info("Усього повторень: $total", 20f))
        r.addView(info("Сьогодні: $today"))
        r.addView(info("Вивчені ≥ 7 днів: $mastered"))
        r.addView(info("У процесі навчання: $learning"))
        r.addView(info("Готові до повторення: $due"))

        cards.groupBy { it.deck }.forEach { (deck, list) ->
            val reviews = list.sumOf { it.repetitions }
            r.addView(info("$deck — $reviews повторень"))
        }
        r.addView(button("🔄 Оновити статистику") { showStats() })
        r.addView(bottomNav(::showHome, ::showDecks, ::showStats, ::showSettings))
        setScreen(r)
    }

    private fun showSettings() {
        val r = root()
        r.addView(title("Налаштування"))
        r.addView(info("Швидкість японської озвучки: ${"%.2f".format(Locale.US, speechRate)}"))
        val seek = SeekBar(this).apply {
            max = 80
            progress = ((speechRate - 0.5f) * 100).toInt().coerceIn(0, 80)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    speechRate = 0.5f + value / 100f
                    prefs.edit().putFloat("speech_rate", speechRate).apply()
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        r.addView(seek)
        val goalInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("daily_goal", 10).toString())
            hint = "Щоденна ціль"
        }
        r.addView(goalInput)
        r.addView(button("💾 Зберегти ціль") {
            val goal = goalInput.text.toString().toIntOrNull()?.coerceIn(1, 200) ?: 10
            prefs.edit().putInt("daily_goal", goal).apply()
            showSettings()
        })
        r.addView(button("⚠ Скинути весь прогрес") {
            AlertDialog.Builder(this)
                .setTitle("Скинути прогрес?")
                .setMessage("Буде видалено інтервали, повторення та статистику.")
                .setNegativeButton("Скасувати", null)
                .setPositiveButton("Скинути") { _, _ -> resetAll() }
                .show()
        })
        r.addView(bottomNav(::showHome, ::showDecks, ::showStats, ::showSettings))
        setScreen(r)
    }

    private fun resetAll() {
        cards.forEach {
            it.interval = 0
            it.repetitions = 0
            it.lapses = 0
            it.dueDay = 0L
        }
        prefs.edit().clear().putFloat("speech_rate", speechRate).apply()
        showHome()
    }

    private fun speak(text: String) {
        if (speechReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myanki-card")
    }

    private fun loadProgress() {
        cards.forEach { c ->
            c.interval = prefs.getInt("${c.id}_interval", 0)
            c.repetitions = prefs.getInt("${c.id}_repetitions", 0)
            c.lapses = prefs.getInt("${c.id}_lapses", 0)
            c.dueDay = prefs.getLong("${c.id}_due", 0L)
        }
    }

    private fun saveCard(c: Card) {
        prefs.edit()
            .putInt("${c.id}_interval", c.interval)
            .putInt("${c.id}_repetitions", c.repetitions)
            .putInt("${c.id}_lapses", c.lapses)
            .putLong("${c.id}_due", c.dueDay)
            .apply()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.JAPAN)
            speechReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts.setSpeechRate(speechRate)
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
